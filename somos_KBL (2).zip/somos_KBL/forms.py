from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired, Length, ValidationError
import re

class TomadorForm(FlaskForm):
    """Formulário para cadastro e edição de tomadores"""
    razao_social = StringField('Razão Social', validators=[
        DataRequired(message="Razão Social é obrigatória"),
        Length(min=3, max=200, message="Razão Social deve ter entre 3 e 200 caracteres")
    ])
    
    cnpj = StringField('CNPJ', validators=[
        DataRequired(message="CNPJ é obrigatório")
    ])
    
    inscricao = StringField('Inscrição Municipal', validators=[])
    usuario = StringField('Usuário', validators=[])
    
    submit = SubmitField('Salvar')
    
    def validate_cnpj(self, field):
        """
        Validação personalizada para CNPJ
        """
        # Remove caracteres não numéricos
        cnpj = re.sub(r'\D', '', field.data)
        
        # Verifica se tem 14 dígitos
        if len(cnpj) != 14:
            raise ValidationError('CNPJ inválido')
        
        # Calcula os dígitos verificadores
        def calc_digito(base):
            soma = sum(int(d) * p for d, p in zip(base, range(len(base)+1, 1, -1)))
            digito = 11 - (soma % 11)
            return digito if digito < 10 else 0
        
        # Primeiro dígito verificador
        base = cnpj[:12]
        digito1 = calc_digito(base)
        if int(cnpj[12]) != digito1:
            raise ValidationError('CNPJ inválido')
        
        # Segundo dígito verificador
        base = cnpj[:13]
        digito2 = calc_digito(base)
        if int(cnpj[13]) != digito2:
            raise ValidationError('CNPJ inválido')