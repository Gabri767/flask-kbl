# REST-GYN - Sistema de Gestão de Notas Fiscais

REST-GYN é uma aplicação web desenvolvida em Flask para gerenciamento de notas fiscais de serviços e retenção de impostos, com foco especial no ISS (Imposto Sobre Serviços) de Goiânia.

## Funcionalidades

- **Gestão de Notas Fiscais**: Cadastro, edição, exclusão e consulta de notas fiscais
- **Gerenciamento de Fornecedores**: Manutenção automática de cadastro de fornecedores
- **Gestão de Tomadores**: Cadastro de empresas tomadoras de serviços
- **Controle de Municípios**: Base de dados de municípios brasileiros com seus respectivos códigos
- **Exportação para Excel**: Exportação dos dados de notas fiscais para planilhas
- **Importação de Municípios**: Funcionalidade para importação de dados de municípios via arquivo TXT

## Tecnologias

- **Backend**: Python com Flask
- **Banco de Dados**: SQLite
- **Frontend**: HTML, CSS, JavaScript (templates Flask)
- **Exportação de Dados**: Pandas, OpenPyXL

## Instalação

1. Clone o repositório:
```
git clone https://github.com/seu-usuario/rest-gyn.git
cd rest-gyn
```

2. Crie um ambiente virtual e ative-o:
```
python -m venv venv
source venv/bin/activate  # No Windows: venv\Scripts\activate
```

3. Instale as dependências:
```
pip install -r requirements.txt
```

4. Execute a aplicação:
```
python app.py
```

A aplicação estará disponível em: http://localhost:5000

## Estrutura do Projeto

- **app.py**: Arquivo principal com as rotas e lógica da aplicação Flask
- **database.py**: Gerenciamento do banco de dados SQLite e operações CRUD
- **forms.py**: Formulários e validações com Flask-WTF
- **templates/**: Diretório com os templates HTML
- **static/**: Arquivos estáticos (CSS, JavaScript, imagens)
- **uploads/**: Diretório para arquivos temporários de upload

## Importação de Municípios

O sistema permite importar municípios a partir de um arquivo TXT no formato:
```
CODIGO;MUNICIPIO;UF
```

Exemplo:
```
5201108;ABADIANIA;GO
5201207;AGUA FRIA DE GOIAS;GO
```

## Exportação de Dados

É possível exportar todas as notas fiscais para um arquivo Excel através da função de exportação, que gera um relatório completo com todos os campos.

## Requisitos

- Python 3.6+
- Flask
- SQLite
- Pandas
- Werkzeug
- OpenPyXL (opcional, para formatação de Excel)

## Uso da Aplicação

1. Na tela inicial, você verá a lista de notas fiscais cadastradas
2. Use o menu para navegar entre as diferentes funcionalidades
3. Para cadastrar uma nota fiscal, clique em "Nova Nota Fiscal"
4. Para gerenciar tomadores, acesse o menu "Tomadores"
5. A importação de municípios está disponível no menu "Importar Municípios"
6. Para exportar os dados para Excel, use o botão "Exportar Excel" na tela principal

## Configurações Iniciais

O sistema já vem com dados pré-cadastrados:
- Estados brasileiros (UFs)
- Tipos de serviço
- Bases de cálculo
- Tipos de recolhimento

## Licença

Este projeto é privado e seu uso é restrito.

## Contato

Para mais informações ou suporte, entre em contato com o desenvolvedor.