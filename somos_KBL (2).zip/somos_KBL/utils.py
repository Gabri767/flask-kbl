# Arquivo: utils.py - Validação e formatação de CNPJ/CPF
import re

def limpar_documento(documento):
    """Remove todos os caracteres não numéricos do documento"""
    if not documento:
        return ""
    return re.sub(r'\D', '', str(documento))

def formatar_cpf(cpf):
    """Formata CPF no padrão 000.000.000-00"""
    cpf_limpo = limpar_documento(cpf)
    if len(cpf_limpo) == 11:
        return f"{cpf_limpo[:3]}.{cpf_limpo[3:6]}.{cpf_limpo[6:9]}-{cpf_limpo[9:11]}"
    return cpf

def formatar_cnpj(cnpj):
    """Formata CNPJ no padrão 00.000.000/0000-00"""
    cnpj_limpo = limpar_documento(cnpj)
    if len(cnpj_limpo) == 14:
        return f"{cnpj_limpo[:2]}.{cnpj_limpo[2:5]}.{cnpj_limpo[5:8]}/{cnpj_limpo[8:12]}-{cnpj_limpo[12:14]}"
    return cnpj

def validar_cpf(cpf):
    """
    Valida CPF brasileiro
    
    Args:
        cpf (str): CPF para validação
        
    Returns:
        bool: True se CPF é válido, False caso contrário
    """
    cpf_limpo = limpar_documento(cpf)
    
    # Verifica se tem 11 dígitos
    if len(cpf_limpo) != 11:
        return False
    
    # Verifica se todos os dígitos são iguais (ex: 111.111.111-11)
    if cpf_limpo == cpf_limpo[0] * 11:
        return False
    
    # Cálculo do primeiro dígito verificador
    soma = 0
    for i in range(9):
        soma += int(cpf_limpo[i]) * (10 - i)
    
    primeiro_digito = (soma * 10) % 11
    if primeiro_digito == 10:
        primeiro_digito = 0
    
    if int(cpf_limpo[9]) != primeiro_digito:
        return False
    
    # Cálculo do segundo dígito verificador
    soma = 0
    for i in range(10):
        soma += int(cpf_limpo[i]) * (11 - i)
    
    segundo_digito = (soma * 10) % 11
    if segundo_digito == 10:
        segundo_digito = 0
    
    if int(cpf_limpo[10]) != segundo_digito:
        return False
    
    return True

def validar_cnpj(cnpj):
    """
    Valida CNPJ brasileiro
    
    Args:
        cnpj (str): CNPJ para validação
        
    Returns:
        bool: True se CNPJ é válido, False caso contrário
    """
    cnpj_limpo = limpar_documento(cnpj)
    
    # Verifica se tem 14 dígitos
    if len(cnpj_limpo) != 14:
        return False
    
    # Verifica se todos os dígitos são iguais
    if cnpj_limpo == cnpj_limpo[0] * 14:
        return False
    
    # Cálculo do primeiro dígito verificador
    pesos1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    soma = 0
    for i in range(12):
        soma += int(cnpj_limpo[i]) * pesos1[i]
    
    primeiro_digito = soma % 11
    if primeiro_digito < 2:
        primeiro_digito = 0
    else:
        primeiro_digito = 11 - primeiro_digito
    
    if int(cnpj_limpo[12]) != primeiro_digito:
        return False
    
    # Cálculo do segundo dígito verificador
    pesos2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    soma = 0
    for i in range(13):
        soma += int(cnpj_limpo[i]) * pesos2[i]
    
    segundo_digito = soma % 11
    if segundo_digito < 2:
        segundo_digito = 0
    else:
        segundo_digito = 11 - segundo_digito
    
    if int(cnpj_limpo[13]) != segundo_digito:
        return False
    
    return True

def identificar_tipo_documento(documento):
    """
    Identifica se o documento é CPF ou CNPJ baseado no número de dígitos
    
    Args:
        documento (str): Documento para identificação
        
    Returns:
        str: 'CPF', 'CNPJ' ou 'DESCONHECIDO'
    """
    documento_limpo = limpar_documento(documento)
    
    if len(documento_limpo) == 11:
        return 'CPF'
    elif len(documento_limpo) == 14:
        return 'CNPJ'
    else:
        return 'DESCONHECIDO'

def processar_entrada_documento(documento):
    """
    Processa e valida um documento (CPF ou CNPJ)
    
    Args:
        documento (str): Documento para processamento
        
    Returns:
        dict: Dicionário com informações do documento processado
            - documento_original: documento original
            - documento_limpo: documento apenas com números
            - documento_formatado: documento formatado
            - tipo: 'CPF', 'CNPJ' ou 'DESCONHECIDO'
            - eh_valido: True/False
            - mensagem: mensagem descritiva
    """
    if not documento:
        return {
            'documento_original': '',
            'documento_limpo': '',
            'documento_formatado': '',
            'tipo': 'VAZIO',
            'eh_valido': False,
            'mensagem': 'Documento não fornecido'
        }
    
    documento_original = str(documento).strip()
    documento_limpo = limpar_documento(documento_original)
    tipo = identificar_tipo_documento(documento_limpo)
    
    resultado = {
        'documento_original': documento_original,
        'documento_limpo': documento_limpo,
        'tipo': tipo,
    }
    
    if tipo == 'CPF':
        eh_valido = validar_cpf(documento_limpo)
        documento_formatado = formatar_cpf(documento_limpo)
        mensagem = 'CPF válido' if eh_valido else 'CPF inválido'
        
    elif tipo == 'CNPJ':
        eh_valido = validar_cnpj(documento_limpo)
        documento_formatado = formatar_cnpj(documento_limpo)
        mensagem = 'CNPJ válido' if eh_valido else 'CNPJ inválido'
        
    else:
        eh_valido = False
        documento_formatado = documento_original
        if len(documento_limpo) == 0:
            mensagem = 'Documento vazio'
        elif len(documento_limpo) < 11:
            mensagem = f'Documento muito curto ({len(documento_limpo)} dígitos)'
        elif len(documento_limpo) > 14:
            mensagem = f'Documento muito longo ({len(documento_limpo)} dígitos)'
        else:
            mensagem = f'Documento com tamanho inválido ({len(documento_limpo)} dígitos)'
    
    resultado.update({
        'documento_formatado': documento_formatado,
        'eh_valido': eh_valido,
        'mensagem': mensagem
    })
    
    return resultado

def validar_documento_completo(documento, obrigatorio=True):
    """
    Validação completa com opções de configuração
    
    Args:
        documento (str): Documento para validação
        obrigatorio (bool): Se True, documento vazio é considerado inválido
        
    Returns:
        dict: Resultado da validação com informações detalhadas
    """
    resultado = processar_entrada_documento(documento)
    
    # Se não é obrigatório e está vazio, considera válido
    if not obrigatorio and not documento:
        resultado['eh_valido'] = True
        resultado['mensagem'] = 'Documento opcional não preenchido'
    
    return resultado

# Função para compatibilidade com o código existente
def _formatar_documento_simples(documento):
    """
    Formatação simples para fallback quando a validação completa falha
    """
    if not documento:
        return ""
    
    documento_limpo = limpar_documento(documento)
    
    if len(documento_limpo) == 11:
        return formatar_cpf(documento_limpo)
    elif len(documento_limpo) == 14:
        return formatar_cnpj(documento_limpo)
    else:
        return documento

# Testes unitários (opcional - pode ser executado para verificar)
def executar_testes():
    """Executa testes básicos das funções de validação"""
    print("=== EXECUTANDO TESTES DE VALIDAÇÃO ===")
    
    # Testes CPF
    cpfs_validos = [
        "11144477735",
        "111.444.777-35",
        "12345678909"
    ]
    
    cpfs_invalidos = [
        "11111111111",  # Todos iguais
        "123456789",    # Muito curto
        "12345678901",  # Dígito verificador inválido
        ""              # Vazio
    ]
    
    print("\n--- Testando CPFs Válidos ---")
    for cpf in cpfs_validos:
        resultado = processar_entrada_documento(cpf)
        print(f"CPF: {cpf} -> {resultado['mensagem']} -> {resultado['documento_formatado']}")
    
    print("\n--- Testando CPFs Inválidos ---")
    for cpf in cpfs_invalidos:
        resultado = processar_entrada_documento(cpf)
        print(f"CPF: {cpf} -> {resultado['mensagem']}")
    
    # Testes CNPJ
    cnpjs_validos = [
        "11222333000181",
        "11.222.333/0001-81"
    ]
    
    cnpjs_invalidos = [
        "11111111111111",  # Todos iguais
        "1122233300018",   # Muito curto
        "11222333000180",  # Dígito verificador inválido
    ]
    
    print("\n--- Testando CNPJs Válidos ---")
    for cnpj in cnpjs_validos:
        resultado = processar_entrada_documento(cnpj)
        print(f"CNPJ: {cnpj} -> {resultado['mensagem']} -> {resultado['documento_formatado']}")
    
    print("\n--- Testando CNPJs Inválidos ---")
    for cnpj in cnpjs_invalidos:
        resultado = processar_entrada_documento(cnpj)
        print(f"CNPJ: {cnpj} -> {resultado['mensagem']}")
    
    print("\n=== TESTES CONCLUÍDOS ===")

if __name__ == "__main__":
    executar_testes()