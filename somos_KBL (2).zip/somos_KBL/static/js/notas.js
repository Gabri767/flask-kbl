let notasTable;

document.addEventListener('DOMContentLoaded', function() {
    // Hide loading on initial page load
    hideLoading();
    
    // Initialize DataTable
    notasTable = $('#notas-table').DataTable({
        language: {
            "sEmptyTable": "Nenhuma nota fiscal encontrada",
            "sInfo": "Mostrando _START_ até _END_ de _TOTAL_ nota(s) fiscal(is)",
            "sInfoEmpty": "Nenhuma nota fiscal encontrada",
            "sInfoFiltered": "(Filtradas de _MAX_ notas fiscais)",
            "sInfoPostFix": "",
            "sInfoThousands": ".",
            "sLengthMenu": "Exibir _MENU_ notas por página",
            "sLoadingRecords": "Carregando notas fiscais...",
            "sProcessing": "Processando...",
            "sZeroRecords": "Nenhuma nota fiscal encontrada",
            "sSearch": "Pesquisar",
            "sSearchPlaceholder": "Buscar registros",
            "oPaginate": {
                "sNext": "Próximo",
                "sPrevious": "Anterior",
                "sFirst": "Primeiro",
                "sLast": "Último"
            }
        },
        processing: true,
        serverSide: false,
        responsive: true,
        order: [[0, 'desc']], // Order by date by default
        pageLength: 10,
        lengthMenu: [[10, 50, -1], [10, 50, "Todos"]],
        columns: [
            { 
                data: 'dt_emissao',
                title: 'Data',
                render: function(data) {
                    if (!data) return '';
                    const date = new Date(data);
                    return date.toLocaleDateString('pt-BR');
                }
            },
            { 
                data: 'numero_nf',
                title: 'NF',
                render: function(data) {
                    if (!data) return '';
                    return data.toString().padStart(6, '0');
                }
            },
            { 
                data: null,
                title: 'Fornecedor',
                render: function(data) {
                    return data.fornecedor ? data.fornecedor.descricao_fornecedor : '-';
                }
            },
            { 
                data: 'cnpj',
                title: 'CNPJ',
                render: function(data) {
                    if (!data) return '';
                    // Remove any non-digit characters
                    const cleanData = data.replace(/\D/g, '');
                    // Format CNPJ
                    return cleanData.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, "$1.$2.$3/$4-$5");
                }
            },
            { 
                data: 'valor_nf',
                title: 'Valor',
                className: 'text-end',
                render: function(data) {
                    return formatCurrency(data || 0);
                }
            },
            { 
                data: 'aliquota',
                title: 'Alíquota',
                className: 'text-end',
                render: function(data) {
                    return (data || 0).toFixed(1) + '%';
                }
            },
            { 
                data: null,
                title: 'ISS',
                className: 'text-end',
                render: function(data) {
                    const valor = data.valor_nf || 0;
                    const aliquota = data.aliquota || 0;
                    return formatCurrency((valor * aliquota) / 100);
                }
            },
            { 
                data: 'referencia',
                title: 'Referecia',
                render: function(data) {
                    if (!data) return '';
                    const [month, year] = (data || '').split('/');
                    return month ? month.padStart(2, '0') + '/' + year : '-';
                }
            },
            {
                data: null,
                title: 'Ações',
                orderable: false,
                className: 'text-center',
                render: function(data) {
                    return `
                        <div class="btn-group">
                            <button class="btn btn-sm btn-primary" onclick="editarNota(${data.id})" title="Editar">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-danger" onclick="excluirNota(${data.id})" title="Excluir">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    `;
                }
            }
        ],
        dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>' +
             '<"row"<"col-sm-12"tr>>' +
             '<"row"<"col-sm-12 col-md-5"i><"col-sm-12 col-md-7"p>>'
    });

    // Carregar dados iniciais
    atualizarListaNotas();
});

function atualizarListaNotas() {
    showLoading();
    try {
        fetch('/api/notas')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Erro na resposta do servidor');
                }
                return response.json();
            })
            .then(data => {
                if (!Array.isArray(data)) {
                    throw new Error('Dados inválidos recebidos do servidor');
                }
                
                // Atualizar tabela
                notasTable.clear();
                notasTable.rows.add(data);
                notasTable.draw();
                
                // Atualizar estatísticas
                atualizarEstatisticas(data);
                
                hideLoading();
            })
            .catch(error => {
                console.error('Erro ao carregar notas:', error);
                showToast('Erro ao carregar notas fiscais: ' + error.message, 'error');
                hideLoading();
            });
    } catch (error) {
        console.error('Erro ao processar requisição:', error);
        showToast('Erro ao processar requisição: ' + error.message, 'error');
        hideLoading();
    }
}

function atualizarEstatisticas(data) {
    try {
        // Total de notas
        const totalNotasEl = document.getElementById('totalNotas');
        if (totalNotasEl) {
            totalNotasEl.textContent = data.length;
        }
        
        // Valor total
        const valorTotal = data.reduce((acc, nota) => acc + (nota.valor_nf || 0), 0);
        const valorTotalEl = document.getElementById('valorTotal');
        if (valorTotalEl) {
            valorTotalEl.textContent = formatCurrency(valorTotal);
        }
        
        // Total de fornecedores únicos
        const fornecedoresUnicos = new Set(data.map(nota => nota.cnpj)).size;
        const totalFornecedoresEl = document.getElementById('totalFornecedores');
        if (totalFornecedoresEl) {
            totalFornecedoresEl.textContent = fornecedoresUnicos;
        }
        
        // ISS total
        const issTotal = data.reduce((acc, nota) => {
            const valor = nota.valor_nf || 0;
            const aliquota = nota.aliquota || 0;
            return acc + ((valor * aliquota) / 100);
        }, 0);
        const valorISSEl = document.getElementById('valorISS');
        if (valorISSEl) {
            valorISSEl.textContent = formatCurrency(issTotal);
        }
    } catch (error) {
        console.error('Erro ao atualizar estatísticas:', error);
        // Continue with table update even if statistics fail
    }
}

function editarNota(id) {
    if (!id) return;
    window.location.href = `/nota?id=${id}`;
}

function excluirNota(id) {
    if (!id) return;
    
    if (confirm('Tem certeza que deseja excluir esta nota fiscal?\nEsta ação não poderá ser desfeita.')) {
        showLoading();
        fetch(`/nota/excluir/${id}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao excluir nota fiscal');
            }
            showToast('Nota fiscal excluída com sucesso!', 'success');
            atualizarListaNotas();
        })
        .catch(error => {
            console.error('Erro:', error);
            showToast('Erro ao excluir nota fiscal: ' + error.message, 'error');
            hideLoading();
        });
    }
}

function exportarExcel() {
    showLoading();
    fetch('/exportar-excel', {
        method: 'POST'
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Erro ao exportar para Excel');
        }
        return response.blob();
    })
    .then(blob => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'notas_fiscais.xlsx';
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
        hideLoading();
        showToast('Arquivo Excel exportado com sucesso!', 'success');
    })
    .catch(error => {
        console.error('Erro:', error);
        showToast('Erro ao exportar para Excel: ' + error.message, 'error');
        hideLoading();
    });
}

function exportarTXT() {
    showLoading();
    fetch('/exportar-txt', {
        method: 'POST'
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Erro ao exportar para TXT');
        }
        return response.blob();
    })
    .then(blob => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'notas_fiscais.txt';
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
        hideLoading();
        showToast('Arquivo TXT exportado com sucesso!', 'success');
    })
    .catch(error => {
        console.error('Erro:', error);
        showToast('Erro ao exportar para TXT: ' + error.message, 'error');
        hideLoading();
    });
}

function formatCurrency(value) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(value);
}

function showToast(message, type = 'info') {
    Toastify({
        text: message,
        duration: 3000,
        gravity: "top",
        position: "right",
        backgroundColor: type === 'success' ? "#28a745" : 
                        type === 'error' ? "#dc3545" : 
                        type === 'warning' ? "#ffc107" : "#17a2b8",
        stopOnFocus: true
    }).showToast();
}

// Loading functions
function showLoading() {
    try {
        const loadingOverlay = document.getElementById('loading-overlay');
        if (loadingOverlay) {
            loadingOverlay.classList.remove('d-none');
            loadingOverlay.classList.add('d-block');
        }
    } catch (error) {
        console.error('Erro ao mostrar loading:', error);
    }
}

function hideLoading() {
    try {
        const loadingOverlay = document.getElementById('loading-overlay');
        if (loadingOverlay) {
            loadingOverlay.classList.add('d-none');
            loadingOverlay.classList.remove('d-block');
        }
    } catch (error) {
        console.error('Erro ao esconder loading:', error);
    }
} 