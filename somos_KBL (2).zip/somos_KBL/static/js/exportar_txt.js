document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('exportForm');
    const confirmModal = new bootstrap.Modal(document.getElementById('confirmModal'));
    const confirmButton = document.getElementById('confirmExport');
    
    // Máscara para CNPJ
    const cnpjInput = document.getElementById('cnpj');
    cnpjInput.addEventListener('input', function(e) {
        let value = e.target.value.replace(/\D/g, '');
        if (value.length <= 14) {
            value = value.replace(/^(\d{2})(\d)/, '$1.$2');
            value = value.replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3');
            value = value.replace(/\.(\d{3})(\d)/, '.$1/$2');
            value = value.replace(/(\d{4})(\d)/, '$1-$2');
        }
        e.target.value = value;
    });

    // Máscara para valor
    const valorInput = document.getElementById('valor');
    valorInput.addEventListener('input', function(e) {
        let value = e.target.value.replace(/\D/g, '');
        value = (parseFloat(value) / 100).toFixed(2);
        e.target.value = value;
    });

    // Preencher data atual nos campos de data
    const today = new Date();
    const dataArquivo = document.getElementById('data_arquivo');
    const dataEmissao = document.getElementById('data_emissao');
    const dataPagamento = document.getElementById('data_pagamento');
    
    // Formatar data como YYYY-MM-DD
    const formatDate = (date) => {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    };

    // Definir valores padrão para as datas
    dataArquivo.value = formatDate(today);
    dataEmissao.value = formatDate(today);
    dataPagamento.value = formatDate(today);

    // Manipular envio do formulário
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        confirmModal.show();
    });

    // Manipular confirmação
    confirmButton.addEventListener('click', function() {
        confirmModal.hide();
        form.submit();
    });
}); 