// cnpj_cpf_formatter.js - Para integrar ao seu sistema existente

class CNPJCPFFormatter {
    /**
     * Remove todos os caracteres não numéricos
     */
    static limparDocumento(documento) {
        if (!documento) return '';
        return documento.toString().replace(/\D/g, '');
    }
    
    /**
     * Formata CPF: 000.000.000-00
     */
    static formatarCPF(cpf) {
        const cpfLimpo = this.limparDocumento(cpf);
        if (cpfLimpo.length === 11) {
            return cpfLimpo.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
        }
        return cpf;
    }
    
    /**
     * Formata CNPJ: 00.000.000/0000-00
     */
    static formatarCNPJ(cnpj) {
        const cnpjLimpo = this.limparDocumento(cnpj);
        if (cnpjLimpo.length === 14) {
            return cnpjLimpo.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
        }
        return cnpj;
    }
    
    /**
     * Detecta automaticamente e formata CPF ou CNPJ
     */
    static formatarAutomatico(documento) {
        if (!documento) return '';
        
        const docLimpo = this.limparDocumento(documento);
        
        if (docLimpo.length === 11) {
            return this.formatarCPF(docLimpo);
        } else if (docLimpo.length === 14) {
            return this.formatarCNPJ(docLimpo);
        } else {
            return documento;
        }
    }
    
    /**
     * Valida CPF com dígitos verificadores
     */
    static validarCPF(cpf) {
        const cpfLimpo = this.limparDocumento(cpf);
        
        // Verificações básicas
        if (cpfLimpo.length !== 11) return false;
        if (/^(\d)\1{10}$/.test(cpfLimpo)) return false; // Todos os dígitos iguais
        
        // Calcular primeiro dígito verificador
        let soma = 0;
        for (let i = 0; i < 9; i++) {
            soma += parseInt(cpfLimpo[i]) * (10 - i);
        }
        let resto = soma % 11;
        let digito1 = resto < 2 ? 0 : 11 - resto;
        
        // Calcular segundo dígito verificador
        soma = 0;
        for (let i = 0; i < 10; i++) {
            soma += parseInt(cpfLimpo[i]) * (11 - i);
        }
        resto = soma % 11;
        let digito2 = resto < 2 ? 0 : 11 - resto;
        
        // Verificar se os dígitos calculados conferem
        return parseInt(cpfLimpo[9]) === digito1 && parseInt(cpfLimpo[10]) === digito2;
    }
    
    /**
     * Valida CNPJ com dígitos verificadores
     */
    static validarCNPJ(cnpj) {
        const cnpjLimpo = this.limparDocumento(cnpj);
        
        // Verificações básicas
        if (cnpjLimpo.length !== 14) return false;
        if (/^(\d)\1{13}$/.test(cnpjLimpo)) return false; // Todos os dígitos iguais
        
        // Calcular primeiro dígito verificador
        const pesos1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
        let soma = 0;
        for (let i = 0; i < 12; i++) {
            soma += parseInt(cnpjLimpo[i]) * pesos1[i];
        }
        let resto = soma % 11;
        let digito1 = resto < 2 ? 0 : 11 - resto;
        
        // Calcular segundo dígito verificador
        const pesos2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
        soma = 0;
        for (let i = 0; i < 13; i++) {
            soma += parseInt(cnpjLimpo[i]) * pesos2[i];
        }
        resto = soma % 11;
        let digito2 = resto < 2 ? 0 : 11 - resto;
        
        // Verificar se os dígitos calculados conferem
        return parseInt(cnpjLimpo[12]) === digito1 && parseInt(cnpjLimpo[13]) === digito2;
    }
    
    /**
     * Valida e retorna informações completas do documento
     */
    static validarDocumento(documento) {
        if (!documento) {
            return {
                valido: false,
                tipo: 'VAZIO',
                formatado: '',
                limpo: '',
                tamanho: 0
            };
        }
        
        const docLimpo = this.limparDocumento(documento);
        
        if (docLimpo.length === 11) {
            const valido = this.validarCPF(documento);
            return {
                valido: valido,
                tipo: 'CPF',
                formatado: this.formatarCPF(docLimpo),
                limpo: docLimpo,
                tamanho: 11
            };
        } else if (docLimpo.length === 14) {
            const valido = this.validarCNPJ(documento);
            return {
                valido: valido,
                tipo: 'CNPJ',
                formatado: this.formatarCNPJ(docLimpo),
                limpo: docLimpo,
                tamanho: 14
            };
        } else {
            return {
                valido: false,
                tipo: 'INVÁLIDO',
                formatado: documento,
                limpo: docLimpo,
                tamanho: docLimpo.length
            };
        }
    }
    
    /**
     * Aplica formatação em tempo real a um campo de input
     */
    static aplicarFormatacaoTempoReal(inputElement, options = {}) {
        const defaultOptions = {
            mostrarStatus: true,
            validarEmTempoReal: true,
            permitirIncompleto: true,
            corValidacao: true
        };
        
        const config = { ...defaultOptions, ...options };
        
        // Criar elementos de status se necessário
        let statusElement = null;
        let infoElement = null;
        
        if (config.mostrarStatus) {
            // Criar elemento de status (ícone)
            statusElement = document.createElement('span');
            statusElement.style.cssText = `
                position: absolute;
                right: 15px;
                top: 50%;
                transform: translateY(-50%);
                font-size: 18px;
                pointer-events: none;
            `;
            
            // Criar elemento de informações
            infoElement = document.createElement('div');
            infoElement.style.cssText = `
                margin-top: 5px;
                padding: 8px;
                border-radius: 4px;
                font-size: 12px;
                display: none;
            `;
            
            // Garantir que o container pai tenha position relative
            const container = inputElement.parentElement;
            if (window.getComputedStyle(container).position === 'static') {
                container.style.position = 'relative';
            }
            
            // Inserir elementos no DOM
            container.appendChild(statusElement);
            container.appendChild(infoElement);
        }
        
        // Função para atualizar status visual
        function atualizarStatus(resultado) {
            if (config.corValidacao) {
                inputElement.classList.remove('cnpj-cpf-valid', 'cnpj-cpf-invalid');
                if (resultado.tamanho >= 11) {
                    inputElement.classList.add(resultado.valido ? 'cnpj-cpf-valid' : 'cnpj-cpf-invalid');
                }
            }
            
            if (statusElement) {
                if (resultado.tamanho >= 11) {
                    statusElement.textContent = resultado.valido ? '✅' : '❌';
                } else {
                    statusElement.textContent = '';
                }
            }
            
            if (infoElement && resultado.tamanho >= 11) {
                infoElement.style.display = 'block';
                infoElement.className = resultado.valido ? 'cnpj-cpf-info-valid' : 'cnpj-cpf-info-invalid';
                infoElement.innerHTML = `
                    <strong>${resultado.tipo}</strong> - ${resultado.valido ? 'Válido' : 'Inválido'}<br>
                    <small>Formatado: <strong>${resultado.formatado}</strong></small>
                `;
            } else if (infoElement) {
                infoElement.style.display = 'none';
            }
        }
        
        // Event listener para formatação em tempo real
        inputElement.addEventListener('input', function(e) {
            let valor = e.target.value;
            
            // Permitir apenas números
            valor = CNPJCPFFormatter.limparDocumento(valor);
            
            // Limitar a 14 dígitos
            if (valor.length > 14) {
                valor = valor.substring(0, 14);
            }
            
            // Aplicar formatação progressiva
            let valorFormatado = '';
            if (valor.length <= 11) {
                // Formatação progressiva de CPF
                if (valor.length > 3) {
                    valorFormatado += valor.substring(0, 3) + '.';
                    if (valor.length > 6) {
                        valorFormatado += valor.substring(3, 6) + '.';
                        if (valor.length > 9) {
                            valorFormatado += valor.substring(6, 9) + '-';
                            valorFormatado += valor.substring(9, 11);
                        } else {
                            valorFormatado += valor.substring(6);
                        }
                    } else {
                        valorFormatado += valor.substring(3);
                    }
                } else {
                    valorFormatado = valor;
                }
            } else {
                // Formatação progressiva de CNPJ
                valorFormatado += valor.substring(0, 2) + '.';
                if (valor.length > 5) {
                    valorFormatado += valor.substring(2, 5) + '.';
                    if (valor.length > 8) {
                        valorFormatado += valor.substring(5, 8) + '/';
                        if (valor.length > 12) {
                            valorFormatado += valor.substring(8, 12) + '-';
                            valorFormatado += valor.substring(12, 14);
                        } else {
                            valorFormatado += valor.substring(8);
                        }
                    } else {
                        valorFormatado += valor.substring(5);
                    }
                } else {
                    valorFormatado += valor.substring(2);
                }
            }
            
            // Atualizar o campo
            e.target.value = valorFormatado;
            
            // Validar e atualizar status
            if (config.validarEmTempoReal) {
                const resultado = CNPJCPFFormatter.validarDocumento(valor);
                atualizarStatus(resultado);
            }
        });
        
        // Event listener para quando sair do campo
        inputElement.addEventListener('blur', function(e) {
            const valor = e.target.value;
            const resultado = CNPJCPFFormatter.validarDocumento(valor);
            
            if (valor && !resultado.valido && !config.permitirIncompleto) {
                alert(`❌ ${resultado.tipo} inválido! Verifique o número digitado.`);
                e.target.focus();
            }
        });
        
        return {
            validar: () => CNPJCPFFormatter.validarDocumento(inputElement.value),
            limpar: () => {
                inputElement.value = '';
                if (statusElement) statusElement.textContent = '';
                if (infoElement) infoElement.style.display = 'none';
                inputElement.classList.remove('cnpj-cpf-valid', 'cnpj-cpf-invalid');
            }
        };
    }
}

// CSS para os estilos de validação (adicionar ao seu CSS)
const cssEstilos = `
    .cnpj-cpf-valid {
        border-color: #28a745 !important;
        background-color: #f8fff9 !important;
    }
    
    .cnpj-cpf-invalid {
        border-color: #dc3545 !important;
        background-color: #fff8f8 !important;
    }
    
    .cnpj-cpf-info-valid {
        background-color: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }
    
    .cnpj-cpf-info-invalid {
        background-color: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }
`;

// Adicionar CSS automaticamente se não existir
if (!document.getElementById('cnpj-cpf-styles')) {
    const style = document.createElement('style');
    style.id = 'cnpj-cpf-styles';
    style.textContent = cssEstilos;
    document.head.appendChild(style);
}

// Função para inicializar automaticamente todos os campos CNPJ/CPF
function inicializarCamposCNPJCPF() {
    // Buscar campos por name, id ou classe
    const seletores = [
        'input[name="cnpj"]',
        'input[name="cpf"]',
        'input[name="cnpj_cpf"]',
        'input[id*="cnpj"]',
        'input[id*="cpf"]',
        'input[class*="cnpj"]',
        'input[class*="cpf"]',
        '.cnpj-cpf-input'
    ];
    
    seletores.forEach(seletor => {
        const campos = document.querySelectorAll(seletor);
        campos.forEach(campo => {
            if (!campo.dataset.cnpjCpfInitialized) {
                CNPJCPFFormatter.aplicarFormatacaoTempoReal(campo);
                campo.dataset.cnpjCpfInitialized = 'true';
                console.log(`✅ Formatação aplicada ao campo: ${campo.name || campo.id || 'sem nome'}`);
            }
        });
    });
}

// Função específica para seu formulário existente
function aplicarFormatacaoNotaFiscal() {
    // Buscar o campo específico do seu formulário
    const campoCNPJ = document.querySelector('input[name="cnpj"]') || 
                      document.getElementById('cnpj') ||
                      document.querySelector('.cnpj-input');
    
    if (campoCNPJ) {
        const formatter = CNPJCPFFormatter.aplicarFormatacaoTempoReal(campoCNPJ, {
            mostrarStatus: true,
            validarEmTempoReal: true,
            permitirIncompleto: false,
            corValidacao: true
        });
        
        console.log('✅ Formatação CNPJ/CPF aplicada ao formulário de nota fiscal');
        return formatter;
    } else {
        console.warn('⚠️ Campo CNPJ/CPF não encontrado no formulário');
        return null;
    }
}

// Função para validar antes do envio do formulário
function validarCNPJCPFAntesEnvio(formElement) {
    const camposCNPJ = formElement.querySelectorAll('input[name*="cnpj"], input[name*="cpf"]');
    
    for (let campo of camposCNPJ) {
        const valor = campo.value.trim();
        if (valor) {
            const resultado = CNPJCPFFormatter.validarDocumento(valor);
            if (!resultado.valido) {
                alert(`❌ ${resultado.tipo} inválido no campo "${campo.name}"!\nVerifique: ${valor}`);
                campo.focus();
                return false;
            }
        }
    }
    
    return true;
}

// Auto-inicialização quando o DOM estiver pronto
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', inicializarCamposCNPJCPF);
} else {
    inicializarCamposCNPJCPF();
}

// Observador para campos adicionados dinamicamente
const observer = new MutationObserver(function(mutations) {
    mutations.forEach(function(mutation) {
        if (mutation.type === 'childList') {
            inicializarCamposCNPJCPF();
        }
    });
});

observer.observe(document.body, {
    childList: true,
    subtree: true
});

// Exportar para uso global
window.CNPJCPFFormatter = CNPJCPFFormatter;
window.aplicarFormatacaoNotaFiscal = aplicarFormatacaoNotaFiscal;
window.validarCNPJCPFAntesEnvio = validarCNPJCPFAntesEnvio;

console.log('🔢 CNPJCPFFormatter carregado e ativo!');