// Funções comuns para toda a aplicação

// Formatador de moeda
function formatMoney(value) {
    return parseFloat(value).toLocaleString('pt-BR', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

// Formatador de números
function formatNumber(value, decimals = 2) {
    value = value.toString().replace(/[^\d.,]/g, '').replace(',', '.');
    return parseFloat(value).toFixed(decimals);
}

// Formatador de data (yyyy-mm-dd para dd/mm/yyyy)
function formatDate(dateString) {
    if (!dateString) return '';
    const parts = dateString.split('-');
    if (parts.length !== 3) return dateString;
    return `${parts[2]}/${parts[1]}/${parts[0]}`;
}

// Validador de CNPJ
function validarCNPJ(cnpj_cpf) {
    cnpj_cpf = cnpj.replace(/[^\d]/g, '');
    
    if (cnpj.length !== 14) return false;
    
    // Elimina CNPJs inválidos conhecidos
    if (/^(\d)\1+$/.test(cnpj)) return false;
    
    // Validação do CNPJ
    let tamanho = cnpj_cpf.length - 2;
    let numeros = cnpj_cpf.substring(0, tamanho);
    const digitos = cnpj.substring(tamanho);
    let soma = 0;
    let pos = tamanho - 7;
    
    for (let i = tamanho; i >= 1; i--) {
        soma += numeros.charAt(tamanho - i) * pos--;
        if (pos < 2) pos = 9;
    }
    
    let resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
    if (resultado !== parseInt(digitos.charAt(0))) return false;
    
    tamanho = tamanho + 1;
    numeros = cnpj_cpf.substring(0, tamanho);
    soma = 0;
    pos = tamanho - 7;
    
    for (let i = tamanho; i >= 1; i--) {
        soma += numeros.charAt(tamanho - i) * pos--;
        if (pos < 2) pos = 9;
    }
    
    resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
    
    return resultado === parseInt(digitos.charAt(1));
}

// Verificar se conseguimos acessar o banco de dados
try {
    const dbFile = await window.fs.readFile('app_rest_gyn.db');
    console.log('✅ Banco de dados encontrado!');
    console.log('Tamanho do arquivo:', dbFile.length, 'bytes');
    
    // Verificar se é um arquivo SQLite válido
    const header = new Uint8Array(dbFile.slice(0, 16));
    const sqliteHeader = Array.from(header).map(b => String.fromCharCode(b)).join('');
    console.log('Header do arquivo:', sqliteHeader);
    
    if (sqliteHeader.startsWith('SQLite format 3')) {
        console.log('✅ Arquivo SQLite válido detectado');
    } else {
        console.log('❌ Não parece ser um arquivo SQLite válido');
    }
    
} catch (error) {
    console.log('❌ Erro ao acessar o banco:', error.message);
    console.log('Possíveis causas:');
    console.log('- Arquivo não foi enviado/carregado');
    console.log('- Problema de permissão');
    console.log('- Arquivo corrompido');
}
