#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Exemplos de uso do validador CNPJ/CPF
Execute: python exemplos_teste.py
"""

import subprocess
import sys
import os

def executar_comando(comando):
    """Executa um comando e captura a saída"""
    print(f"\n💻 Executando: {comando}")
    print("=" * 60)
    
    try:
        # Executa o comando
        resultado = subprocess.run(
            comando, 
            shell=True, 
            capture_output=True, 
            text=True, 
            encoding='utf-8'
        )
        
        # Imprime a saída
        if resultado.stdout:
            print(resultado.stdout)
        
        if resultado.stderr:
            print(f"❌ Erro: {resultado.stderr}")
        
        print(f"📊 Código de saída: {resultado.returncode}")
        
        return resultado.returncode == 0
        
    except Exception as e:
        print(f"❌ Erro ao executar comando: {e}")
        return False

def main():
    """Executa todos os exemplos de teste"""
    print("🧪 EXEMPLOS DE USO DO VALIDADOR CNPJ/CPF")
    print("=" * 60)
    
    # Verificar se o validador existe
    if not os.path.exists('validador.py'):
        print("❌ Arquivo validador.py não encontrado!")
        print("📝 Certifique-se de que o arquivo validador.py está no mesmo diretório.")
        return
    
    # Lista de comandos para testar
    comandos_teste = [
        # CNPJ válido sem formatação
        "python validador.py -cnpj 18781203000128",
        
        # CNPJ válido com formatação
        "python validador.py -cnpj 18.781.203/0001-28",
        
        # CNPJ inválido
        "python validador.py -cnpj 12345678000100",
        
        # CPF válido sem formatação  
        "python validador.py -cpf 11144477735",
        
        # CPF válido com formatação
        "python validador.py -cpf 111.444.777-35",
        
        # CPF inválido
        "python validador.py -cpf 12345678901",
        
        # Detecção automática - CNPJ
        "python validador.py -auto 18781203000128",
        
        # Detecção automática - CPF
        "python validador.py -auto 111.444.777-35",
        
        # Detecção automática com verbose
        "python validador.py -auto 18.781.203/0001-28 -v",
        
        # Documento inválido (tamanho errado)
        "python validador.py -auto 123456",
        
        # Teste com help
        "python validador.py --help",
    ]
    
    sucessos = 0
    total = len(comandos_teste)
    
    for i, comando in enumerate(comandos_teste, 1):
        print(f"\n🔍 TESTE {i}/{total}")
        sucesso = executar_comando(comando)
        if sucesso:
            sucessos += 1
        
        # Pausa entre comandos para melhor visualização
        if i < total:
            print("\n" + "⏸️ " * 20)
            input("Pressione ENTER para continuar...")
    
    # Resumo final
    print("\n" + "🎯 RESUMO DOS TESTES " + "🎯")
    print("=" * 60)
    print(f"✅ Sucessos: {sucessos}/{total}")
    print(f"❌ Falhas: {total - sucessos}/{total}")
    
    if sucessos == total:
        print("🎉 Todos os testes foram executados com sucesso!")
    else:
        print("⚠️ Alguns testes falharam. Verifique as mensagens acima.")

def testar_casos_especificos():
    """Testa casos específicos mencionados no exemplo"""
    print("\n🎯 TESTANDO CASOS ESPECÍFICOS")
    print("=" * 60)
    
    casos = [
        ("18781203000128", "CNPJ sem formatação"),
        ("18.781.203/0001-28", "CNPJ com formatação"),
        ("111.444.777-35", "CPF com formatação"),
        ("11144477735", "CPF sem formatação"),
    ]
    
    for documento, descricao in casos:
        print(f"\n📋 Testando: {descricao}")
        print(f"📄 Documento: {documento}")
        
        # Teste automático
        comando = f"python validador.py -auto {documento} -v"
        executar_comando(comando)

def criar_script_batch():
    """Cria um script batch para Windows"""
    conteudo_batch = """@echo off
echo ========================================
echo    VALIDADOR CNPJ/CPF - TESTE RAPIDO
echo ========================================
echo.

echo Testando CNPJ valido: 18781203000128
python validador.py -cnpj 18781203000128
echo.

echo Testando CNPJ formatado: 18.781.203/0001-28  
python validador.py -cnpj 18.781.203/0001-28
echo.

echo Testando CPF valido: 111.444.777-35
python validador.py -cpf 111.444.777-35
echo.

echo Testando deteccao automatica: 18781203000128
python validador.py -auto 18781203000128 -v
echo.

echo Testando documento invalido: 123456
python validador.py -auto 123456
echo.

echo ========================================
echo           TESTES CONCLUIDOS
echo ========================================
pause
"""
    
    with open('teste_validador.bat', 'w', encoding='utf-8') as f:
        f.write(conteudo_batch)
    
    print("📝 Arquivo 'teste_validador.bat' criado!")
    print("💡 No Windows, execute: teste_validador.bat")

def criar_script_shell():
    """Cria um script shell para Linux/Mac"""
    conteudo_shell = """#!/bin/bash
echo "========================================"
echo "   VALIDADOR CNPJ/CPF - TESTE RAPIDO"
echo "========================================"
echo

echo "Testando CNPJ válido: 18781203000128"
python validador.py -cnpj 18781203000128
echo

echo "Testando CNPJ formatado: 18.781.203/0001-28"  
python validador.py -cnpj 18.781.203/0001-28
echo

echo "Testando CPF válido: 111.444.777-35"
python validador.py -cpf 111.444.777-35
echo

echo "Testando detecção automática: 18781203000128"
python validador.py -auto 18781203000128 -v
echo

echo "Testando documento inválido: 123456"
python validador.py -auto 123456
echo

echo "========================================"
echo "          TESTES CONCLUÍDOS"
echo "========================================"
read -p "Pressione ENTER para sair..."
"""
    
    with open('teste_validador.sh', 'w', encoding='utf-8') as f:
        f.write(conteudo_shell)
    
    # Tornar executável
    os.chmod('teste_validador.sh', 0o755)
    
    print("📝 Arquivo 'teste_validador.sh' criado!")
    print("💡 No Linux/Mac, execute: ./teste_validador.sh")

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == '--casos':
        testar_casos_especificos()
    elif len(sys.argv) > 1 and sys.argv[1] == '--scripts':
        criar_script_batch()
        criar_script_shell()
    else:
        main()
        
        print("\n" + "📚 OPÇÕES ADICIONAIS " + "📚")
        print("=" * 60)
        print("🔸 python exemplos_teste.py --casos")
        print("   Testa apenas os casos específicos")
        print()
        print("🔸 python exemplos_teste.py --scripts")  
        print("   Cria scripts .bat e .sh para testes rápidos")