# Arquivo: teste_validacao.py - Script para testar a validação de CNPJ e CPF
"""
Script de teste para validação de CNPJ e CPF
Execute este arquivo para testar as funcionalidades de validação
"""

import sys
import os

# Adicionar o diretório atual ao path para importar os módulos
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from utils import (
    processar_entrada_documento,
    validar_documento_completo,
    executar_testes,
    validar_cpf,
    validar_cnpj,
    formatar_cpf,
    formatar_cnpj
)

def teste_casos_reais():
    """Testa casos reais de uso com CNPJ e CPF"""
    print("=== TESTE COM CASOS REAIS ===\n")
    
    # Casos de teste
    casos_teste = [
        # CPFs válidos
        ("11144477735", "CPF válido"),
        ("111.444.777-35", "CPF válido com formatação"),
        
        # CPFs inválidos
        ("11111111111", "CPF com todos os dígitos iguais"),
        ("12345678901", "CPF com dígito verificador inválido"),
        
        # CNPJs válidos
        ("11222333000181", "CNPJ válido"),
        ("11.222.333/0001-81", "CNPJ válido com formatação"),
        
        # CNPJs inválidos
        ("11111111111111", "CNPJ com todos os dígitos iguais"),
        ("11222333000180", "CNPJ com dígito verificador inválido"),
        
        # Casos especiais
        ("", "Documento vazio"),
        ("123", "Documento muito curto"),
        ("123456789012345", "Documento muito longo"),
        ("abc123def456", "Documento com letras"),
        
        # Casos do KLB
        ("09238316000190", "CNPJ do KLB ACCOUTING"),
        ("53052749153", "CPF/Usuário da prefeitura")
    ]
    
    for documento, descricao in casos_teste:
        print(f"Testando: {descricao}")
        print(f"Entrada: '{documento}'")
        
        resultado = processar_entrada_documento(documento)
        
        print(f"✓ Tipo: {resultado['tipo']}")
        print(f"✓ Documento limpo: '{resultado['documento_limpo']}'")
        print(f"✓ Documento formatado: '{resultado['documento_formatado']}'")
        print(f"✓ É válido: {resultado['eh_valido']}")
        print(f"✓ Mensagem: {resultado['mensagem']}")
        print("-" * 60)

def teste_banco_dados():
    """Testa a integração com o banco de dados"""
    print("\n=== TESTE DE INTEGRAÇÃO COM BANCO DE DADOS ===\n")
    
    try:
        from database import DatabaseManager
        
        # Criar instância do banco
        db = DatabaseManager()
        
        # Testar inserção de tomador KLB
        print("1. Testando inserção do tomador KLB...")
        sucesso = db.insert_klb_tomador()
        print(f"   Resultado: {'✅ Sucesso' if sucesso else '❌ Falha'}")
        
        # Testar validação de integridade
        print("\n2. Executando validação de integridade...")
        problemas = db.validar_integridade_documentos()
        print(f"   Problemas encontrados: {len(problemas)}")
        
        # Testar inserção de fornecedor com CNPJ válido
        print("\n3. Testando inserção de fornecedor...")
        fornecedor_id = db.insert_fornecedor(
            cnpj="12345678000195",  # CNPJ válido fictício
            descricao="Fornecedor Teste LTDA",
            uf="GO",
            municipio="Goiânia",
            cod_municipio="5208707",
            fora_pais="Não",
            cadastrado_goiania="Sim"
        )
        print(f"   Resultado: {'✅ Fornecedor inserido com ID ' + str(fornecedor_id) if fornecedor_id else '❌ Falha na inserção'}")
        
        # Testar inserção de fornecedor com CNPJ inválido
        print("\n4. Testando inserção de fornecedor com CNPJ inválido...")
        fornecedor_invalido = db.insert_fornecedor(
            cnpj="11111111111111",  # CNPJ inválido
            descricao="Fornecedor Inválido LTDA",
            uf="GO",
            municipio="Goiânia",
            cod_municipio="5208707",
            fora_pais="Não",
            cadastrado_goiania="Sim"
        )
        print(f"   Resultado: {'❌ Corretamente rejeitado' if not fornecedor_invalido else '⚠️  Inserção aceita indevidamente'}")
        
    except ImportError:
        print("❌ Módulo database não encontrado. Certifique-se de que o arquivo database.py está no mesmo diretório.")
    except Exception as e:
        print(f"❌ Erro durante teste do banco: {e}")

def teste_formatacao():
    """Testa especificamente as funções de formatação"""
    print("\n=== TESTE DE FORMATAÇÃO ===\n")
    
    # Testes de CPF
    cpfs_teste = [
        "12345678909",
        "123.456.789-09",
        "123 456 789 09",
        "12345678901234"  # Muito longo
    ]
    
    print("--- Formatação de CPF ---")
    for cpf in cpfs_teste:
        formatado = formatar_cpf(cpf)
        print(f"'{cpf}' → '{formatado}'")
    
    # Testes de CNPJ
    cnpjs_teste = [
        "12345678000195",
        "12.345.678/0001-95",
        "12 345 678 000195",
        "123456789"  # Muito curto
    ]
    
    print("\n--- Formatação de CNPJ ---")
    for cnpj in cnpjs_teste:
        formatado = formatar_cnpj(cnpj)
        print(f"'{cnpj}' → '{formatado}'")

def teste_validacao_especifica():
    """Testa especificamente as funções de validação"""
    print("\n=== TESTE DE VALIDAÇÃO ESPECÍFICA ===\n")
    
    # CPFs para teste
    cpfs_validos = ["11144477735", "12345678909"]
    cpfs_invalidos = ["11111111111", "12345678901", "123456789"]
    
    print("--- Validação de CPF ---")
    print("CPFs válidos:")
    for cpf in cpfs_validos:
        resultado = validar_cpf(cpf)
        print(f"  {cpf}: {'✅ Válido' if resultado else '❌ Inválido'}")
    
    print("CPFs inválidos:")
    for cpf in cpfs_invalidos:
        resultado = validar_cpf(cpf)
        print(f"  {cpf}: {'⚠️  Indevidamente válido' if resultado else '✅ Corretamente inválido'}")
    
    # CNPJs para teste
    cnpjs_validos = ["11222333000181", "12345678000195"]
    cnpjs_invalidos = ["11111111111111", "11222333000180", "123456789012"]
    
    print("\n--- Validação de CNPJ ---")
    print("CNPJs válidos:")
    for cnpj in cnpjs_validos:
        resultado = validar_cnpj(cnpj)
        print(f"  {cnpj}: {'✅ Válido' if resultado else '❌ Inválido'}")
    
    print("CNPJs inválidos:")
    for cnpj in cnpjs_invalidos:
        resultado = validar_cnpj(cnpj)
        print(f"  {cnpj}: {'⚠️  Indevidamente válido' if resultado else '✅ Corretamente inválido'}")

def teste_casos_extremos():
    """Testa casos extremos e edge cases"""
    print("\n=== TESTE DE CASOS EXTREMOS ===\n")
    
    casos_extremos = [
        None,                    # Valor None
        "",                      # String vazia
        "   ",                   # Só espaços
        "000.000.000-00",        # CPF com zeros
        "00.000.000/0000-00",    # CNPJ com zeros
        "123-456-789-09",        # Formatação não padrão
        "12.345.678/0001.95",    # CNPJ com ponto em vez de hífen
        "12345678901234567890",  # Muito longo
        "abcdefghijk",           # Só letras
        "123abc456def789",       # Misturado
        "\n12345678909\n",       # Com quebras de linha
        "12.345.678/0001-95 ",   # Com espaço no final
    ]
    
    for i, caso in enumerate(casos_extremos, 1):
        print(f"Caso {i}: {repr(caso)}")
        try:
            resultado = processar_entrada_documento(caso)
            print(f"  ✓ Processado: {resultado['tipo']} - {resultado['mensagem']}")
            print(f"  ✓ Formatado: '{resultado['documento_formatado']}'")
        except Exception as e:
            print(f"  ❌ Erro: {e}")
        print()

def menu_interativo():
    """Menu interativo para testes"""
    print("\n=== MENU INTERATIVO DE TESTES ===\n")
    
    while True:
        print("Escolha uma opção:")
        print("1. Executar todos os testes automáticos")
        print("2. Testar documento específico")
        print("3. Teste de casos reais")
        print("4. Teste de formatação")
        print("5. Teste de validação específica")
        print("6. Teste de casos extremos")
        print("7. Teste de integração com banco de dados")
        print("0. Sair")
        
        opcao = input("\nDigite sua opção: ").strip()
        
        if opcao == "0":
            print("Saindo...")
            break
        elif opcao == "1":
            executar_testes()
            teste_casos_reais()
            teste_formatacao()
            teste_validacao_especifica()
            teste_casos_extremos()
            teste_banco_dados()
        elif opcao == "2":
            documento = input("Digite o CNPJ ou CPF para testar: ").strip()
            if documento:
                resultado = processar_entrada_documento(documento)
                print(f"\nResultado para '{documento}':")
                print(f"  Tipo: {resultado['tipo']}")
                print(f"  Válido: {resultado['eh_valido']}")
                print(f"  Formatado: '{resultado['documento_formatado']}'")
                print(f"  Mensagem: {resultado['mensagem']}")
            else:
                print("Nenhum documento informado.")
        elif opcao == "3":
            teste_casos_reais()
        elif opcao == "4":
            teste_formatacao()
        elif opcao == "5":
            teste_validacao_especifica()
        elif opcao == "6":
            teste_casos_extremos()
        elif opcao == "7":
            teste_banco_dados()
        else:
            print("Opção inválida!")
        
        input("\nPressione Enter para continuar...")
        print("\n" + "="*60 + "\n")

def demonstracao_uso():
    """Demonstra como usar as funções de validação no seu código"""
    print("=== DEMONSTRAÇÃO DE USO ===\n")
    
    print("# Como usar a validação em seu código:\n")
    
    codigo_exemplo = '''
# 1. Importar as funções
from utils import processar_entrada_documento, validar_documento_completo

# 2. Validar um documento básico
documento = "123.456.789-09"
resultado = processar_entrada_documento(documento)

if resultado['eh_valido']:
    print(f"Documento válido: {resultado['documento_formatado']}")
    # Prosseguir com a operação
else:
    print(f"Documento inválido: {resultado['mensagem']}")
    # Tratar o erro

# 3. Validação com opções
resultado = validar_documento_completo(documento, obrigatorio=True)

# 4. Uso em formulários
def validar_formulario(dados):
    cnpj = dados.get('cnpj', '')
    
    validacao = processar_entrada_documento(cnpj)
    
    if not validacao['eh_valido'] and cnpj:
        return False, f"CNPJ inválido: {validacao['mensagem']}"
    
    # Usar o documento formatado para salvar
    dados['cnpj'] = validacao['documento_formatado']
    return True, "Válido"

# 5. Integração com banco de dados (como implementado)
class MinhaClasse:
    def validar_e_formatar_documento(self, documento, campo_nome="documento", obrigatorio=True):
        resultado = validar_documento_completo(documento, obrigatorio)
        if not resultado['eh_valido'] and obrigatorio:
            raise ValueError(f"{campo_nome} inválido: {resultado['mensagem']}")
        return resultado['documento_formatado']
    '''
    
    print(codigo_exemplo)

if __name__ == "__main__":
    print("🔍 SISTEMA DE VALIDAÇÃO DE CNPJ E CPF")
    print("=" * 50)
    
    # Mostrar demonstração de uso
    demonstracao_uso()
    
    # Executar testes básicos
    print("\n📋 EXECUTANDO TESTES BÁSICOS...")
    executar_testes()
    
    # Menu interativo
    menu_interativo()